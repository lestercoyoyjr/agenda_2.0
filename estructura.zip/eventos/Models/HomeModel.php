<?php
class HomeModel extends Query{
    public function __construct()
    {
        parent::__construct();
    }
}

?>